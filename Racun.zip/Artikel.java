public class Artikel {
        private String ime;
        private double cena;  //Brez DDV
        private String ean;
        private double davcnaStopnja;

        public Artikel(String ime, double cena, String ean, double davcnaStopnja){
            this.ime = ime;
            this.cena = cena;
            this.ean = ean;
            this.davcnaStopnja = davcnaStopnja;
        }

        public Artikel(){
            this.ime = "Prazen";
        }
        public String getIme(){
            return ime;
        }
        public double getCena(){
            return cena;
        }
        public void setCena(double cena){
            this.cena = cena;
        }
        public void setIme(String ime) {
            this.ime = ime;
        }
        public String getEan(){
               return ean;
        }
        public void setEan(String ean){
             this.ean = ean;
        }
        public double getDavcnaStopnja() {
            return davcnaStopnja;
        }
        public void setDavcnaStopnja(double davcnaStopnja) {
            this.davcnaStopnja = davcnaStopnja;
        }
        public String ToString1(){
            return "Naziv izdelka: " + getIme() + ", Cena izdelka: " + getCena() + ", EAN koda: " + getEan();
        }
}
