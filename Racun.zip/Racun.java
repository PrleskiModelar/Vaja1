import java.time.LocalDateTime;
import java.util.ArrayList;

class G {
    static int stevec = 1;
}
public class Racun extends Artikli{
    private ArrayList<Artikli> seznam = new ArrayList<Artikli>();
   // private  Artikli seznamArtiklov;
    private int id;
    private double znesek ; //izracunajZnesek();
    private LocalDateTime datum;

    public Racun(String ime, double cena, String ean, double davcnaStopnja, double kolicina){
        super(ime,cena,ean,davcnaStopnja,kolicina);

        this.id = G.stevec;
        G.stevec++;
        this.datum = LocalDateTime.now();
        this.znesek = izracunajZnesek(seznam, davcnaStopnja);
        this.seznam.add(this);
    }

    public void Dodaj(String ime, double cena, String ean, double davcnaStopnja, double kolicina){
        Artikli c = new Artikli(ime,cena,ean,davcnaStopnja,kolicina);       //
        this.znesek = izracunajZnesek(seznam, davcnaStopnja);
        this.seznam.add(c);
    }

    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return id;
    }
    public double getZnesek(){
        return znesek;
    }


    public double izracunajZnesek(ArrayList<Artikli> seznam, double davcnaStopnja){ // double cena, double kolicina, double davcnaStopnja
        double obseg = 0;
        for(int i = 0; i < seznam.size(); i++) {

            obseg = obseg + seznam.get(i).getKolicina() * seznam.get(i).getCena() + (seznam.get(i).getKolicina() * seznam.get(i).getCena()* (davcnaStopnja / 100))  ;    //cena * kolicina + (cena * kolicina * (davcnaStopnja / 100));

        }
        return obseg;
    }




    public String ToString3() {
           return "ID racuna: " + getId() + ", Datum izdaje: " + getDatum()+ ", Znesek skupaj: " + znesek;
    }

    public LocalDateTime getDatum() {
        return datum;
    }

    public ArrayList<Artikli> getSeznam() {
        return seznam;
    }

    public void Zbrisi( int stevilka){
        seznam.remove(stevilka);

    }
}