import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        double ddv22 = 22;
        double ddv95 = 9.5;


        ArrayList<Racun> racuni = new ArrayList<Racun>();



        Racun r1 = new Racun("Banane", 2.3, "1000000100", ddv22 , 2.1);

        //System.out.println(r1.ToString3() + ", " + r1.getSeznam().get(0).ToString2() + ", " + r1.getSeznam().get(0).ToString1());

        r1.Dodaj("Jagode", 3.45, "100290494", ddv95, 6.8);
       // System.out.println(r1.ToString3() + ", " + r1.getSeznam().get(1).ToString2() + ", " + r1.getSeznam().get(1).ToString1());

        r1.Dodaj("Jagod1e", 6.45, "100290495464", ddv22, 0.8);

        r1.Zbrisi(0);
        racuni.add(r1);
        System.out.println("To je na končnem računu:  ");
        System.out.println(r1.ToString3());
        for(int t= 0; t < racuni.size(); t++) {
            for (int i = 0; i < r1.getSeznam().size(); i++) {
                System.out.println(racuni.get(t).getSeznam().get(i).ToString2() + ", " + racuni.get(t).getSeznam().get(i).ToString1());
            }
        }
        }
    }

