public class Artikli extends Artikel {

    private Artikel artikel;
    private double kolicina;


    public Artikli(String ime, double cena, String ean, double davcnaStopnja, double kolicina){
       super(ime,cena,ean, davcnaStopnja);
       this.kolicina = kolicina;
    }
    public Artikli(){
        super();
    }


    public void setArtikel(Artikel artikel) {
        this.artikel = artikel;
    }
    public double getKolicina(){
        return kolicina;
    }
    public void setKolicina(double kolicina){
        this.kolicina = kolicina;
    }

    public String ToString2(){
        return "Kolicina: " + getKolicina();
    }


}
